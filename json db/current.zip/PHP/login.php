<?php
// server should keep session data for AT LEAST 2 days
ini_set('session.gc_maxlifetime', 172800);

// each client should remember their session id for EXACTLY 2 days
session_set_cookie_params(172800);

header("Location: lobby.php");
session_start();
echo '<body style="background-color:black">';
echo '<font color="white">'; 

//Spielername
$name = "";
$name = $_POST['name'];




 if ($name === "reset"){
        
        //clear distribution 
            
            for($runset=5;$runset<=10;$runset = $runset +1){
            for($runPlayer=1;$runPlayer<= $runset;$runPlayer= $runPlayer+1){
             
             $myfile = fopen("./Setting/$runset Players/Player $runPlayer/Name.txt", "w") or die("Unable to open file!");
             $txt= "";
             fwrite($myfile, $txt);
             fclose($myfile);
             
            }
            }
            
            //clear Lobby
            
           //empyty json file
            $playerlist = '{"Player_1":"","Player_2":"","Player_3":"","Player_4":"","Player_5":"","Player_6":"","Player_7":"","Player_8":"","Player_9":"","Player_10":""}';
            
            $newJsonString = json_encode($playerlist);
            file_put_contents("DB/lobbylist.json", $playerlist);
            
            
            //clear playercount
             $myfile = fopen("amount.txt", "w") or die("Unable to open file!");
                fwrite($myfile, "");
                fclose($myfile);
            
            //clear observer    
            $myfile = fopen("isobserved.txt", "w") or die("Unable to open file!");
                fwrite($myfile, "");
                fclose($myfile);    
        
        echo "Reset erfolgreich <br /><br>";
        $_SESSION['position']=0;
        
        
       
        // player login
    }else if(!($name==="") AND (!isset($_SESSION['position'])) AND (!isset($_SESSION['username']))) {
    
        //Spielername in seine Session eintragen
        $_SESSION['username'] = $name;
    
    

        //Spieler in SessionListe eintragen
        
                        // read json file
            $strJsonFileContents = file_get_contents("DB/lobbylist.json");
            // Convert to array 
            $playerlist = json_decode($strJsonFileContents, true);  
    
        for($pos=1;$pos<= 10;$pos= $pos + 1){
            // if position is empty
            if( $playerlist["Player_$pos"] === ""){
           
                    
                    // change value of player
                    $playerlist["Player_$pos"] = $name;
                    $newJsonString = json_encode($playerlist);
                    file_put_contents("DB/lobbylist.json", $newJsonString);
    
                    $_SESSION['position']= $pos;
                    $pos=10;
                    
                    
            }        
                    
        }            
  
    }
    
echo "<a href=\"logout.php\">New Game</a>";


?>
